#!/usr/bin/env node
"use strict";

class CosmicHyperGlyphCodex {
  constructor() {
    this.mAnchor = ["╟", "╬", "彡", "☠", "☣", "ꐦ", "⺡", "⚡", "⚙", "▰", "🜏", "⚝", "⎈"];
    this.mCore   = ["∅", "×", "Ξ", "Ψ", "Ω", "Ϡ", "ஸ", "⁂", "❖", "⧉", "☥", "☩", "⟡"];
    this.mFlux   = ["¹", "³", "°", "϶", "″", "‡", "†", "⁑", "♣", "♦", "§", "¶", "⫷"];
    this.mPhase  = ["▰", "▲", "▼", "◆", "⟁", "⌖", "⊗", "⨀", "⊛", "⊙", "⌭", "⎔", "⫸"];
    this.mNexus  = ["Ψ", "Ω", "Ξ", "𝚺", "𝚯", "𝚷", "𝛀", "𝛙", "ℵ", "ℏ", "ℓ", "ℯ"];

    this.lens = [
      this.mAnchor.length,
      this.mCore.length,
      this.mFlux.length,
      this.mPhase.length,
      this.mNexus.length
    ];

    this.delimiters = ["⟡⎈", "⫷⚡⫸", "⧉❖⧉", "⎈⟁⎈"];
  }

  _getChaoticByte(idx, roundNum) {
    const val = Math.sin(idx * 12.9898 + roundNum * 78.233) * 43758.5453123;
    return Math.floor((val - Math.floor(val)) * 256) & 0xFF;
  }

  _mixForward(byteVal, idx) {
    let v = byteVal & 0xFF;
    for (let r = 0; r < 3; r++) {
      const cByte = this._getChaoticByte(idx, r);
      v = (v ^ cByte) & 0xFF;
      v = ((v << 3) | (v >>> 5)) & 0xFF;
      v = (v + 0x37) & 0xFF;
    }
    return v;
  }

  _mixBackward(mixedVal, idx) {
    let v = mixedVal & 0xFF;
    for (let r = 2; r >= 0; r--) {
      const cByte = this._getChaoticByte(idx, r);
      v = (v - 0x37) & 0xFF;
      v = ((v >>> 3) | (v << 5)) & 0xFF;
      v = (v ^ cByte) & 0xFF;
    }
    return v;
  }

  encode(plaintext) {
    const clusters = [];
    for (let idx = 0; idx < plaintext.length; idx++) {
      const raw = plaintext.charCodeAt(idx) & 0xFF;
      const mixed = this._mixForward(raw, idx);

      const c0 = mixed % this.lens[0];
      const c1 = Math.floor(mixed / this.lens[0]) % this.lens[1];
      const c2 = Math.floor(mixed / (this.lens[0] * this.lens[1])) % this.lens[2];
      const c3 = (idx * 7) % this.lens[3];
      const c4 = (mixed ^ idx) % this.lens[4];

      clusters.push(
        this.mAnchor[c0] +
        this.mCore[c1] +
        this.mFlux[c2] +
        this.mPhase[c3] +
        this.mNexus[c4]
      );
    }

    let encodedStream = "";
    for (let i = 0; i < clusters.length; i++) {
      encodedStream += clusters[i];
      if (i < clusters.length - 1) {
        encodedStream += this.delimiters[i % this.delimiters.length];
      }
    }
    return encodedStream;
  }

  decode(ciphertext) {
    let normalized = ciphertext;
    for (const d of this.delimiters) {
      normalized = normalized.split(d).join("▵");
    }
    const clusters = normalized.split("▵");

    let decodedChars = "";
    for (let idx = 0; idx < clusters.length; idx++) {
      const symbols = Array.from(clusters[idx]);
      if (symbols.length < 5) continue;

      const [p0, p1, p2, , p4] = symbols;
      const c0 = this.mAnchor.indexOf(p0);
      const c1 = this.mCore.indexOf(p1);
      const c2 = this.mFlux.indexOf(p2);
      const c4 = this.mNexus.indexOf(p4);

      if (c0 === -1 || c1 === -1 || c2 === -1 || c4 === -1) continue;

      const mixed = c0 + c1 * this.lens[0] + c2 * this.lens[0] * this.lens[1];
      const original = this._mixBackward(mixed, idx);
      decodedChars += String.fromCharCode(original);
    }
    return decodedChars;
  }
}

const codex = new CosmicHyperGlyphCodex();

// Expose globally on globalThis automatically when required
globalThis.CosmicHyperGlyphCodex = codex;

// Support direct CLI execution: xenocrypt encode "hello"
if (require.main === module) {
  const [, , mode, ...args] = process.argv;
  const input = args.join(" ");
  if (mode === "encode" && input) {
    console.log(codex.encode(input));
  } else if (mode === "decode" && input) {
    console.log(codex.decode(input));
  } else {
    console.log("Usage: xenocrypt <encode|decode> <text>");
  }
}

module.exports = codex;
